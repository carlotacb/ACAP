var searchData=
[
  ['to_5fstd_5flogic',['To_Std_Logic',['../classacceso__MD_1_1comport.html#a2cdd60a606d3b202d0d4db773c48b901',1,'acceso_MD.comport.To_Std_Logic()'],['../classacceso__MI_1_1comport.html#a2cdd60a606d3b202d0d4db773c48b901',1,'acceso_MI.comport.To_Std_Logic()']]]
];
