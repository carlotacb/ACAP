var searchData=
[
  ['_5finicializa_5fmem_5fi_5fpkg',['_inicializa_mem_I_pkg',['../class__inicializa__mem__I__pkg.html',1,'']]],
  ['_5finicializa_5fmem_5fpkg',['_inicializa_mem_pkg',['../class__inicializa__mem__pkg.html',1,'']]]
];
