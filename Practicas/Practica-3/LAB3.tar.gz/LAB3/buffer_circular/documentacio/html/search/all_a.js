var searchData=
[
  ['q',['Q',['../classreg.html#a8786915d5cfd2b0b023eb7e94af2f838',1,'reg']]]
];
