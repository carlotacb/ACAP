var searchData=
[
  ['d',['D',['../classreg.html#a77fe9f5f3d9f7d76842058c55b605e9b',1,'reg']]],
  ['datoe',['datoE',['../classbuffer__circular.html#a58d8191cf98ec5486d88d5354c0fcdfa',1,'buffer_circular']]],
  ['datol',['datoL',['../classbuffer__circular.html#aba2eebe032661371c2b9caf7d3ff9968',1,'buffer_circular']]],
  ['dire',['dirE',['../classBR.html#a1a467775f3217361e8b0cba476020d6e',1,'BR']]],
  ['dirl',['dirL',['../classBR.html#a524e8dcc938283aefc888e202895cc43',1,'BR']]]
];
