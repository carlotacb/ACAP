var searchData=
[
  ['br',['BR',['../classcomponentes__buffer__circular__pkg.html#a95a8bdb6b1f4ac5c3da0c028f3ab8204',1,'componentes_buffer_circular_pkg']]]
];
