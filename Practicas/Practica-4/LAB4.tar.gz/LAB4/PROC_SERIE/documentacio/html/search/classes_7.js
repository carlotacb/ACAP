var searchData=
[
  ['inicializa_5fmem_5fi_5fpkg',['inicializa_mem_I_pkg',['../classinicializa__mem__I__pkg.html',1,'']]],
  ['inicializa_5fmem_5fpkg',['inicializa_mem_pkg',['../classinicializa__mem__pkg.html',1,'']]]
];
