var searchData=
[
  ['param_5fdisenyo_5fpkg',['param_disenyo_pkg',['../classparam__disenyo__pkg.html',1,'']]],
  ['proc_5fmd_5fmi',['proc_MD_MI',['../classproc__MD__MI.html',1,'']]]
];
